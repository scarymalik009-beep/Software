const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  // School Info
  getSchoolInfo: () => ipcRenderer.invoke('db:getSchoolInfo'),
  saveSchoolInfo: (info) => ipcRenderer.invoke('db:saveSchoolInfo', info),

  // Users
  getUsers: () => ipcRenderer.invoke('db:getUsers'),
  getUserByUsername: (username) => ipcRenderer.invoke('db:getUserByUsername', username),
  saveUser: (user) => ipcRenderer.invoke('db:saveUser', user),
  deleteUser: (userId) => ipcRenderer.invoke('db:deleteUser', userId),
  getCurrentUser: () => ipcRenderer.invoke('db:getCurrentUser'),
  setCurrentUser: (user) => ipcRenderer.invoke('db:setCurrentUser', user),

  // Academic Years
  getAcademicYears: () => ipcRenderer.invoke('db:getAcademicYears'),
  saveAcademicYear: (year) => ipcRenderer.invoke('db:saveAcademicYear', year),

  // Classes
  getClasses: () => ipcRenderer.invoke('db:getClasses'),
  saveClass: (classInfo) => ipcRenderer.invoke('db:saveClass', classInfo),
  deleteClass: (classId) => ipcRenderer.invoke('db:deleteClass', classId),

  // Fee Heads
  getFeeHeads: () => ipcRenderer.invoke('db:getFeeHeads'),
  saveFeeHead: (head) => ipcRenderer.invoke('db:saveFeeHead', head),

  // Students
  getStudents: () => ipcRenderer.invoke('db:getStudents'),
  saveStudent: (student) => ipcRenderer.invoke('db:saveStudent', student),
  deleteStudent: (studentId) => ipcRenderer.invoke('db:deleteStudent', studentId),

  // Fee Records
  getFeeRecords: () => ipcRenderer.invoke('db:getFeeRecords'),
  saveFeeRecord: (record) => ipcRenderer.invoke('db:saveFeeRecord', record),

  // Teachers
  getTeachers: () => ipcRenderer.invoke('db:getTeachers'),
  saveTeacher: (teacher) => ipcRenderer.invoke('db:saveTeacher', teacher),
  deleteTeacher: (teacherId) => ipcRenderer.invoke('db:deleteTeacher', teacherId),

  // Salary Payments
  getSalaryPayments: () => ipcRenderer.invoke('db:getSalaryPayments'),
  saveSalaryPayment: (payment) => ipcRenderer.invoke('db:saveSalaryPayment', payment),

  // Google API Config
  getGoogleApiConfig: () => ipcRenderer.invoke('db:getGoogleApiConfig'),
  saveGoogleApiConfig: (config) => ipcRenderer.invoke('db:saveGoogleApiConfig', config),

  // Settings
  getSetting: (key) => ipcRenderer.invoke('db:getSetting', key),
  setSetting: (key, value) => ipcRenderer.invoke('db:setSetting', key, value),

  // Audit Logs
  addAuditLog: (log) => ipcRenderer.invoke('db:addAuditLog', log),
  getAuditLogs: () => ipcRenderer.invoke('db:getAuditLogs'),

  // Backup / Restore
  exportAllData: () => ipcRenderer.invoke('db:exportAllData'),
  importAllData: (data) => ipcRenderer.invoke('db:importAllData', data),

  // File dialogs
  showSaveDialog: (options) => ipcRenderer.invoke('dialog:showSave', options),
  showOpenDialog: (options) => ipcRenderer.invoke('dialog:showOpen', options),
  writeFile: (filePath, data) => ipcRenderer.invoke('fs:writeFile', filePath, data),
  readFile: (filePath) => ipcRenderer.invoke('fs:readFile', filePath),
});
