const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');

const isDev = process.env.NODE_ENV === 'development';

let mainWindow;
let db;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 1024,
    minHeight: 600,
    title: 'School Fee Manager Pro',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    show: false,
    backgroundColor: '#f9fafb',
  });

  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'));
  }

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// Initialize database
function initDatabase() {
  db = require('./database');
}

app.whenReady().then(() => {
  initDatabase();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// ─── IPC Handlers ────────────────────────────────────────────────────────────

// School Info
ipcMain.handle('db:getSchoolInfo', () => db.getSchoolInfo());
ipcMain.handle('db:saveSchoolInfo', (_, info) => db.saveSchoolInfo(info));

// Users
ipcMain.handle('db:getUsers', () => db.getUsers());
ipcMain.handle('db:getUserByUsername', (_, username) => db.getUserByUsername(username));
ipcMain.handle('db:saveUser', (_, user) => db.saveUser(user));
ipcMain.handle('db:deleteUser', (_, userId) => db.deleteUser(userId));
ipcMain.handle('db:getCurrentUser', () => db.getCurrentUser());
ipcMain.handle('db:setCurrentUser', (_, user) => db.setCurrentUser(user));

// Academic Years
ipcMain.handle('db:getAcademicYears', () => db.getAcademicYears());
ipcMain.handle('db:saveAcademicYear', (_, year) => db.saveAcademicYear(year));

// Classes
ipcMain.handle('db:getClasses', () => db.getClasses());
ipcMain.handle('db:saveClass', (_, classInfo) => db.saveClass(classInfo));
ipcMain.handle('db:deleteClass', (_, classId) => db.deleteClass(classId));

// Fee Heads
ipcMain.handle('db:getFeeHeads', () => db.getFeeHeads());
ipcMain.handle('db:saveFeeHead', (_, head) => db.saveFeeHead(head));

// Students
ipcMain.handle('db:getStudents', () => db.getStudents());
ipcMain.handle('db:saveStudent', (_, student) => db.saveStudent(student));
ipcMain.handle('db:deleteStudent', (_, studentId) => db.deleteStudent(studentId));

// Fee Records
ipcMain.handle('db:getFeeRecords', () => db.getFeeRecords());
ipcMain.handle('db:saveFeeRecord', (_, record) => db.saveFeeRecord(record));

// Teachers
ipcMain.handle('db:getTeachers', () => db.getTeachers());
ipcMain.handle('db:saveTeacher', (_, teacher) => db.saveTeacher(teacher));
ipcMain.handle('db:deleteTeacher', (_, teacherId) => db.deleteTeacher(teacherId));

// Salary Payments
ipcMain.handle('db:getSalaryPayments', () => db.getSalaryPayments());
ipcMain.handle('db:saveSalaryPayment', (_, payment) => db.saveSalaryPayment(payment));

// Google API Config
ipcMain.handle('db:getGoogleApiConfig', () => db.getGoogleApiConfig());
ipcMain.handle('db:saveGoogleApiConfig', (_, config) => db.saveGoogleApiConfig(config));

// Settings
ipcMain.handle('db:getSetting', (_, key) => db.getSetting(key));
ipcMain.handle('db:setSetting', (_, key, value) => db.setSetting(key, value));

// Audit Logs
ipcMain.handle('db:addAuditLog', (_, log) => db.addAuditLog(log));
ipcMain.handle('db:getAuditLogs', () => db.getAuditLogs());

// Backup / Restore
ipcMain.handle('db:exportAllData', () => db.exportAllData());
ipcMain.handle('db:importAllData', (_, data) => { db.importAllData(data); return true; });

// File System
ipcMain.handle('dialog:showSave', (_, options) => dialog.showSaveDialog(mainWindow, options));
ipcMain.handle('dialog:showOpen', (_, options) => dialog.showOpenDialog(mainWindow, options));
ipcMain.handle('fs:writeFile', (_, filePath, data) => {
  fs.writeFileSync(filePath, data, 'utf8');
  return true;
});
ipcMain.handle('fs:readFile', (_, filePath) => {
  return fs.readFileSync(filePath, 'utf8');
});
