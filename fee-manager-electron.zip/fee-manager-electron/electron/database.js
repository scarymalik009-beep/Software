const Database = require('better-sqlite3');
const path = require('path');
const { app } = require('electron');

let db;

function getDb() {
  if (!db) {
    const dbPath = path.join(app.getPath('userData'), 'school-fee-manager.db');
    db = new Database(dbPath);
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');
    initializeSchema();
  }
  return db;
}

function initializeSchema() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS school_info (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      schoolName TEXT NOT NULL,
      schoolCode TEXT,
      address TEXT,
      city TEXT,
      state TEXT,
      pincode TEXT,
      phonePrimary TEXT,
      phoneSecondary TEXT,
      email TEXT,
      website TEXT,
      logoPath TEXT,
      principalName TEXT,
      affiliationBoard TEXT,
      affiliationNumber TEXT,
      establishedYear TEXT,
      motto TEXT
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId TEXT UNIQUE NOT NULL,
      username TEXT UNIQUE NOT NULL,
      passwordHash TEXT NOT NULL,
      fullName TEXT NOT NULL,
      email TEXT,
      phone TEXT,
      role TEXT NOT NULL DEFAULT 'staff',
      isActive INTEGER NOT NULL DEFAULT 1,
      lastLogin TEXT,
      createdAt TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS academic_years (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      yearName TEXT NOT NULL,
      startDate TEXT NOT NULL,
      endDate TEXT NOT NULL,
      isCurrent INTEGER NOT NULL DEFAULT 0,
      isActive INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS classes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      className TEXT NOT NULL,
      classCode TEXT NOT NULL,
      displayOrder INTEGER NOT NULL DEFAULT 0,
      isActive INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS sections (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      classId INTEGER NOT NULL,
      sectionName TEXT NOT NULL,
      capacity INTEGER NOT NULL DEFAULT 40,
      isActive INTEGER NOT NULL DEFAULT 1,
      FOREIGN KEY (classId) REFERENCES classes(id)
    );

    CREATE TABLE IF NOT EXISTS fee_heads (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      headName TEXT NOT NULL,
      headCode TEXT NOT NULL,
      description TEXT,
      isRecurring INTEGER NOT NULL DEFAULT 1,
      frequency TEXT NOT NULL DEFAULT 'monthly',
      isMandatory INTEGER NOT NULL DEFAULT 1,
      displayOrder INTEGER NOT NULL DEFAULT 0,
      isActive INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS students (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      studentId TEXT UNIQUE NOT NULL,
      admissionNumber TEXT NOT NULL,
      rollNumber TEXT,
      firstName TEXT NOT NULL,
      lastName TEXT,
      dateOfBirth TEXT,
      gender TEXT NOT NULL,
      bloodGroup TEXT,
      photoPath TEXT,
      fatherName TEXT NOT NULL,
      fatherPhone TEXT,
      fatherEmail TEXT,
      motherName TEXT,
      motherPhone TEXT,
      guardianName TEXT,
      guardianPhone TEXT,
      academicYearId INTEGER NOT NULL,
      classId INTEGER NOT NULL,
      sectionId INTEGER,
      admissionDate TEXT NOT NULL,
      monthlyFee REAL NOT NULL DEFAULT 0,
      feeCategory TEXT NOT NULL DEFAULT 'regular',
      transportOpted INTEGER NOT NULL DEFAULT 0,
      transportFee REAL NOT NULL DEFAULT 0,
      address TEXT,
      city TEXT,
      state TEXT,
      pincode TEXT,
      status TEXT NOT NULL DEFAULT 'active',
      remarks TEXT,
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS fee_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      receiptNumber TEXT UNIQUE NOT NULL,
      studentId INTEGER NOT NULL,
      academicYearId INTEGER NOT NULL,
      feeMonth INTEGER NOT NULL,
      feeYear INTEGER NOT NULL,
      totalFee REAL NOT NULL DEFAULT 0,
      concessionAmount REAL NOT NULL DEFAULT 0,
      lateFee REAL NOT NULL DEFAULT 0,
      previousDue REAL NOT NULL DEFAULT 0,
      netPayable REAL NOT NULL DEFAULT 0,
      amountPaid REAL NOT NULL DEFAULT 0,
      balanceDue REAL NOT NULL DEFAULT 0,
      paymentDate TEXT NOT NULL,
      paymentMode TEXT NOT NULL DEFAULT 'cash',
      paymentReference TEXT,
      bankName TEXT,
      chequeNumber TEXT,
      status TEXT NOT NULL DEFAULT 'paid',
      remarks TEXT,
      collectedBy INTEGER NOT NULL,
      createdAt TEXT NOT NULL,
      FOREIGN KEY (studentId) REFERENCES students(id)
    );

    CREATE TABLE IF NOT EXISTS teachers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      teacherId TEXT UNIQUE NOT NULL,
      firstName TEXT NOT NULL,
      lastName TEXT,
      email TEXT,
      phone TEXT,
      gender TEXT NOT NULL,
      dateOfBirth TEXT,
      joiningDate TEXT NOT NULL,
      designation TEXT NOT NULL,
      department TEXT,
      qualification TEXT,
      salary REAL NOT NULL DEFAULT 0,
      bankName TEXT,
      accountNumber TEXT,
      address TEXT,
      city TEXT,
      status TEXT NOT NULL DEFAULT 'active',
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS salary_payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      paymentId TEXT UNIQUE NOT NULL,
      teacherId INTEGER NOT NULL,
      month INTEGER NOT NULL,
      year INTEGER NOT NULL,
      basicSalary REAL NOT NULL DEFAULT 0,
      allowances REAL NOT NULL DEFAULT 0,
      deductions REAL NOT NULL DEFAULT 0,
      netSalary REAL NOT NULL DEFAULT 0,
      paymentDate TEXT NOT NULL,
      paymentMode TEXT NOT NULL DEFAULT 'cash',
      paymentReference TEXT,
      status TEXT NOT NULL DEFAULT 'paid',
      remarks TEXT,
      paidBy INTEGER NOT NULL,
      createdAt TEXT NOT NULL,
      FOREIGN KEY (teacherId) REFERENCES teachers(id)
    );

    CREATE TABLE IF NOT EXISTS google_api_config (
      id INTEGER PRIMARY KEY DEFAULT 1,
      isEnabled INTEGER NOT NULL DEFAULT 0,
      credentialsJson TEXT,
      clientEmail TEXT,
      spreadsheetId TEXT,
      lastSyncAt TEXT,
      syncFrequency INTEGER NOT NULL DEFAULT 15,
      autoSyncEnabled INTEGER NOT NULL DEFAULT 1,
      syncStatus TEXT DEFAULT 'idle',
      lastSyncError TEXT
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp TEXT NOT NULL,
      userId INTEGER NOT NULL DEFAULT 0,
      userName TEXT NOT NULL DEFAULT 'System',
      action TEXT NOT NULL,
      entity TEXT NOT NULL,
      entityId INTEGER NOT NULL DEFAULT 0,
      details TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS app_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    INSERT OR IGNORE INTO google_api_config (id, isEnabled, syncFrequency, autoSyncEnabled)
    VALUES (1, 0, 15, 1);
  `);
}

// ─── School Info ─────────────────────────────────────────────────────────────
function getSchoolInfo() {
  return getDb().prepare('SELECT * FROM school_info LIMIT 1').get() || null;
}
function saveSchoolInfo(info) {
  const db = getDb();
  const existing = db.prepare('SELECT id FROM school_info LIMIT 1').get();
  if (existing) {
    db.prepare(`UPDATE school_info SET schoolName=?, schoolCode=?, address=?, city=?, state=?,
      pincode=?, phonePrimary=?, phoneSecondary=?, email=?, website=?, logoPath=?,
      principalName=?, affiliationBoard=?, affiliationNumber=?, establishedYear=?, motto=?
      WHERE id=?`).run(
      info.schoolName, info.schoolCode, info.address, info.city, info.state,
      info.pincode, info.phonePrimary, info.phoneSecondary, info.email, info.website,
      info.logoPath, info.principalName, info.affiliationBoard, info.affiliationNumber,
      info.establishedYear, info.motto, existing.id
    );
  } else {
    db.prepare(`INSERT INTO school_info (schoolName, schoolCode, address, city, state,
      pincode, phonePrimary, phoneSecondary, email, website, logoPath,
      principalName, affiliationBoard, affiliationNumber, establishedYear, motto)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
      info.schoolName, info.schoolCode, info.address, info.city, info.state,
      info.pincode, info.phonePrimary, info.phoneSecondary, info.email, info.website,
      info.logoPath, info.principalName, info.affiliationBoard, info.affiliationNumber,
      info.establishedYear, info.motto
    );
  }
}

// ─── Users ───────────────────────────────────────────────────────────────────
function getUsers() {
  return getDb().prepare('SELECT * FROM users').all();
}
function getUserByUsername(username) {
  return getDb().prepare('SELECT * FROM users WHERE LOWER(username) = LOWER(?)').get(username) || null;
}
function saveUser(user) {
  const db = getDb();
  const existing = db.prepare('SELECT id FROM users WHERE id=?').get(user.id);
  if (existing) {
    db.prepare(`UPDATE users SET userId=?, username=?, passwordHash=?, fullName=?, email=?,
      phone=?, role=?, isActive=?, lastLogin=? WHERE id=?`).run(
      user.userId, user.username, user.passwordHash, user.fullName, user.email,
      user.phone, user.role, user.isActive ? 1 : 0, user.lastLogin, user.id
    );
  } else {
    db.prepare(`INSERT INTO users (userId, username, passwordHash, fullName, email,
      phone, role, isActive, lastLogin, createdAt) VALUES (?,?,?,?,?,?,?,?,?,?)`).run(
      user.userId, user.username, user.passwordHash, user.fullName, user.email,
      user.phone, user.role, user.isActive ? 1 : 0, user.lastLogin, user.createdAt
    );
    const inserted = db.prepare('SELECT last_insert_rowid() as id').get();
    user.id = inserted.id;
  }
  return user;
}
function deleteUser(userId) {
  getDb().prepare('DELETE FROM users WHERE id=?').run(userId);
}
function getCurrentUser() {
  const val = getDb().prepare("SELECT value FROM app_settings WHERE key='current_user'").get();
  return val ? JSON.parse(val.value) : null;
}
function setCurrentUser(user) {
  if (user) {
    getDb().prepare("INSERT OR REPLACE INTO app_settings (key, value) VALUES ('current_user', ?)").run(JSON.stringify(user));
  } else {
    getDb().prepare("DELETE FROM app_settings WHERE key='current_user'").run();
  }
}

// ─── Academic Years ───────────────────────────────────────────────────────────
function getAcademicYears() {
  return getDb().prepare('SELECT * FROM academic_years').all().map(r => ({ ...r, isCurrent: !!r.isCurrent, isActive: !!r.isActive }));
}
function saveAcademicYear(year) {
  const db = getDb();
  if (year.isCurrent) db.prepare('UPDATE academic_years SET isCurrent=0').run();
  const existing = db.prepare('SELECT id FROM academic_years WHERE id=?').get(year.id);
  if (existing) {
    db.prepare('UPDATE academic_years SET yearName=?, startDate=?, endDate=?, isCurrent=?, isActive=? WHERE id=?').run(
      year.yearName, year.startDate, year.endDate, year.isCurrent ? 1 : 0, year.isActive ? 1 : 0, year.id
    );
  } else {
    db.prepare('INSERT INTO academic_years (yearName, startDate, endDate, isCurrent, isActive) VALUES (?,?,?,?,?)').run(
      year.yearName, year.startDate, year.endDate, year.isCurrent ? 1 : 0, year.isActive ? 1 : 0
    );
  }
}

// ─── Classes ─────────────────────────────────────────────────────────────────
function getClasses() {
  const db = getDb();
  const classes = db.prepare('SELECT * FROM classes ORDER BY displayOrder').all();
  return classes.map(c => ({
    ...c,
    isActive: !!c.isActive,
    sections: db.prepare('SELECT * FROM sections WHERE classId=?').all(c.id).map(s => ({ ...s, isActive: !!s.isActive }))
  }));
}
function saveClass(classInfo) {
  const db = getDb();
  const existing = db.prepare('SELECT id FROM classes WHERE id=?').get(classInfo.id);
  if (existing) {
    db.prepare('UPDATE classes SET className=?, classCode=?, displayOrder=?, isActive=? WHERE id=?').run(
      classInfo.className, classInfo.classCode, classInfo.displayOrder, classInfo.isActive ? 1 : 0, classInfo.id
    );
  } else {
    db.prepare('INSERT INTO classes (className, classCode, displayOrder, isActive) VALUES (?,?,?,?)').run(
      classInfo.className, classInfo.classCode, classInfo.displayOrder, classInfo.isActive ? 1 : 0
    );
    const inserted = db.prepare('SELECT last_insert_rowid() as id').get();
    classInfo.id = inserted.id;
  }
  if (classInfo.sections) {
    db.prepare('DELETE FROM sections WHERE classId=?').run(classInfo.id);
    for (const s of classInfo.sections) {
      db.prepare('INSERT INTO sections (classId, sectionName, capacity, isActive) VALUES (?,?,?,?)').run(
        classInfo.id, s.sectionName, s.capacity, s.isActive ? 1 : 0
      );
    }
  }
}
function deleteClass(classId) {
  const db = getDb();
  db.prepare('DELETE FROM sections WHERE classId=?').run(classId);
  db.prepare('DELETE FROM classes WHERE id=?').run(classId);
}

// ─── Fee Heads ────────────────────────────────────────────────────────────────
function getFeeHeads() {
  return getDb().prepare('SELECT * FROM fee_heads ORDER BY displayOrder').all().map(r => ({
    ...r, isRecurring: !!r.isRecurring, isMandatory: !!r.isMandatory, isActive: !!r.isActive
  }));
}
function saveFeeHead(head) {
  const db = getDb();
  const existing = db.prepare('SELECT id FROM fee_heads WHERE id=?').get(head.id);
  if (existing) {
    db.prepare('UPDATE fee_heads SET headName=?, headCode=?, description=?, isRecurring=?, frequency=?, isMandatory=?, displayOrder=?, isActive=? WHERE id=?').run(
      head.headName, head.headCode, head.description, head.isRecurring ? 1 : 0,
      head.frequency, head.isMandatory ? 1 : 0, head.displayOrder, head.isActive ? 1 : 0, head.id
    );
  } else {
    db.prepare('INSERT INTO fee_heads (headName, headCode, description, isRecurring, frequency, isMandatory, displayOrder, isActive) VALUES (?,?,?,?,?,?,?,?)').run(
      head.headName, head.headCode, head.description, head.isRecurring ? 1 : 0,
      head.frequency, head.isMandatory ? 1 : 0, head.displayOrder, head.isActive ? 1 : 0
    );
  }
}

// ─── Students ─────────────────────────────────────────────────────────────────
function getStudents() {
  return getDb().prepare('SELECT * FROM students').all().map(s => ({ ...s, transportOpted: !!s.transportOpted }));
}
function saveStudent(student) {
  const db = getDb();
  const existing = db.prepare('SELECT id FROM students WHERE id=?').get(student.id);
  if (existing) {
    db.prepare(`UPDATE students SET studentId=?, admissionNumber=?, rollNumber=?, firstName=?, lastName=?,
      dateOfBirth=?, gender=?, bloodGroup=?, fatherName=?, fatherPhone=?, fatherEmail=?,
      motherName=?, motherPhone=?, guardianName=?, guardianPhone=?, academicYearId=?,
      classId=?, sectionId=?, admissionDate=?, monthlyFee=?, feeCategory=?,
      transportOpted=?, transportFee=?, address=?, city=?, state=?, pincode=?,
      status=?, remarks=?, updatedAt=? WHERE id=?`).run(
      student.studentId, student.admissionNumber, student.rollNumber, student.firstName, student.lastName,
      student.dateOfBirth, student.gender, student.bloodGroup, student.fatherName, student.fatherPhone, student.fatherEmail,
      student.motherName, student.motherPhone, student.guardianName, student.guardianPhone, student.academicYearId,
      student.classId, student.sectionId, student.admissionDate, student.monthlyFee, student.feeCategory,
      student.transportOpted ? 1 : 0, student.transportFee, student.address, student.city, student.state, student.pincode,
      student.status, student.remarks, new Date().toISOString(), student.id
    );
  } else {
    db.prepare(`INSERT INTO students (studentId, admissionNumber, rollNumber, firstName, lastName,
      dateOfBirth, gender, bloodGroup, fatherName, fatherPhone, fatherEmail,
      motherName, motherPhone, guardianName, guardianPhone, academicYearId,
      classId, sectionId, admissionDate, monthlyFee, feeCategory,
      transportOpted, transportFee, address, city, state, pincode,
      status, remarks, createdAt, updatedAt) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
      student.studentId, student.admissionNumber, student.rollNumber, student.firstName, student.lastName,
      student.dateOfBirth, student.gender, student.bloodGroup, student.fatherName, student.fatherPhone, student.fatherEmail,
      student.motherName, student.motherPhone, student.guardianName, student.guardianPhone, student.academicYearId,
      student.classId, student.sectionId, student.admissionDate, student.monthlyFee, student.feeCategory,
      student.transportOpted ? 1 : 0, student.transportFee, student.address, student.city, student.state, student.pincode,
      student.status, student.remarks, student.createdAt, student.updatedAt
    );
    const inserted = db.prepare('SELECT last_insert_rowid() as id').get();
    student.id = inserted.id;
  }
  return student;
}
function deleteStudent(studentId) {
  const db = getDb();
  const feeCount = db.prepare('SELECT COUNT(*) as c FROM fee_records WHERE studentId=?').get(studentId).c;
  if (feeCount > 0) {
    db.prepare("UPDATE students SET status='left', remarks=COALESCE(remarks,'')||' [Marked as Left]', updatedAt=? WHERE id=?").run(new Date().toISOString(), studentId);
    return { softDeleted: true, feeCount };
  } else {
    db.prepare('DELETE FROM students WHERE id=?').run(studentId);
    return { softDeleted: false };
  }
}

// ─── Fee Records ──────────────────────────────────────────────────────────────
function getFeeRecords() {
  return getDb().prepare('SELECT * FROM fee_records').all();
}
function saveFeeRecord(record) {
  const db = getDb();
  const existing = db.prepare('SELECT id FROM fee_records WHERE id=?').get(record.id);
  if (existing) {
    db.prepare(`UPDATE fee_records SET receiptNumber=?, studentId=?, academicYearId=?, feeMonth=?, feeYear=?,
      totalFee=?, concessionAmount=?, lateFee=?, previousDue=?, netPayable=?, amountPaid=?,
      balanceDue=?, paymentDate=?, paymentMode=?, paymentReference=?, bankName=?, chequeNumber=?,
      status=?, remarks=?, collectedBy=? WHERE id=?`).run(
      record.receiptNumber, record.studentId, record.academicYearId, record.feeMonth, record.feeYear,
      record.totalFee, record.concessionAmount, record.lateFee, record.previousDue, record.netPayable,
      record.amountPaid, record.balanceDue, record.paymentDate, record.paymentMode, record.paymentReference,
      record.bankName, record.chequeNumber, record.status, record.remarks, record.collectedBy, record.id
    );
  } else {
    db.prepare(`INSERT INTO fee_records (receiptNumber, studentId, academicYearId, feeMonth, feeYear,
      totalFee, concessionAmount, lateFee, previousDue, netPayable, amountPaid,
      balanceDue, paymentDate, paymentMode, paymentReference, bankName, chequeNumber,
      status, remarks, collectedBy, createdAt) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
      record.receiptNumber, record.studentId, record.academicYearId, record.feeMonth, record.feeYear,
      record.totalFee, record.concessionAmount, record.lateFee, record.previousDue, record.netPayable,
      record.amountPaid, record.balanceDue, record.paymentDate, record.paymentMode, record.paymentReference,
      record.bankName, record.chequeNumber, record.status, record.remarks, record.collectedBy, record.createdAt
    );
  }
}

// ─── Teachers ─────────────────────────────────────────────────────────────────
function getTeachers() {
  return getDb().prepare('SELECT * FROM teachers').all();
}
function saveTeacher(teacher) {
  const db = getDb();
  const existing = db.prepare('SELECT id FROM teachers WHERE id=?').get(teacher.id);
  if (existing) {
    db.prepare(`UPDATE teachers SET teacherId=?, firstName=?, lastName=?, email=?, phone=?,
      gender=?, dateOfBirth=?, joiningDate=?, designation=?, department=?, qualification=?,
      salary=?, bankName=?, accountNumber=?, address=?, city=?, status=?, updatedAt=? WHERE id=?`).run(
      teacher.teacherId, teacher.firstName, teacher.lastName, teacher.email, teacher.phone,
      teacher.gender, teacher.dateOfBirth, teacher.joiningDate, teacher.designation, teacher.department,
      teacher.qualification, teacher.salary, teacher.bankName, teacher.accountNumber,
      teacher.address, teacher.city, teacher.status, new Date().toISOString(), teacher.id
    );
  } else {
    db.prepare(`INSERT INTO teachers (teacherId, firstName, lastName, email, phone,
      gender, dateOfBirth, joiningDate, designation, department, qualification,
      salary, bankName, accountNumber, address, city, status, createdAt, updatedAt) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
      teacher.teacherId, teacher.firstName, teacher.lastName, teacher.email, teacher.phone,
      teacher.gender, teacher.dateOfBirth, teacher.joiningDate, teacher.designation, teacher.department,
      teacher.qualification, teacher.salary, teacher.bankName, teacher.accountNumber,
      teacher.address, teacher.city, teacher.status, teacher.createdAt, teacher.updatedAt
    );
    const inserted = db.prepare('SELECT last_insert_rowid() as id').get();
    teacher.id = inserted.id;
  }
  return teacher;
}
function deleteTeacher(teacherId) {
  getDb().prepare('DELETE FROM teachers WHERE id=?').run(teacherId);
}

// ─── Salary Payments ──────────────────────────────────────────────────────────
function getSalaryPayments() {
  return getDb().prepare('SELECT * FROM salary_payments').all();
}
function saveSalaryPayment(payment) {
  const db = getDb();
  const existing = db.prepare('SELECT id FROM salary_payments WHERE id=?').get(payment.id);
  if (existing) {
    db.prepare(`UPDATE salary_payments SET paymentId=?, teacherId=?, month=?, year=?,
      basicSalary=?, allowances=?, deductions=?, netSalary=?, paymentDate=?,
      paymentMode=?, paymentReference=?, status=?, remarks=?, paidBy=? WHERE id=?`).run(
      payment.paymentId, payment.teacherId, payment.month, payment.year,
      payment.basicSalary, payment.allowances, payment.deductions, payment.netSalary,
      payment.paymentDate, payment.paymentMode, payment.paymentReference,
      payment.status, payment.remarks, payment.paidBy, payment.id
    );
  } else {
    db.prepare(`INSERT INTO salary_payments (paymentId, teacherId, month, year,
      basicSalary, allowances, deductions, netSalary, paymentDate,
      paymentMode, paymentReference, status, remarks, paidBy, createdAt) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
      payment.paymentId, payment.teacherId, payment.month, payment.year,
      payment.basicSalary, payment.allowances, payment.deductions, payment.netSalary,
      payment.paymentDate, payment.paymentMode, payment.paymentReference,
      payment.status, payment.remarks, payment.paidBy, payment.createdAt
    );
  }
}

// ─── Google API Config ────────────────────────────────────────────────────────
function getGoogleApiConfig() {
  const row = getDb().prepare('SELECT * FROM google_api_config WHERE id=1').get();
  if (!row) return { isEnabled: false, syncFrequency: 15, autoSyncEnabled: true };
  return { ...row, isEnabled: !!row.isEnabled, autoSyncEnabled: !!row.autoSyncEnabled };
}
function saveGoogleApiConfig(config) {
  getDb().prepare(`UPDATE google_api_config SET isEnabled=?, credentialsJson=?, clientEmail=?,
    spreadsheetId=?, lastSyncAt=?, syncFrequency=?, autoSyncEnabled=?, syncStatus=?, lastSyncError=?
    WHERE id=1`).run(
    config.isEnabled ? 1 : 0, config.credentialsJson, config.clientEmail,
    config.spreadsheetId, config.lastSyncAt, config.syncFrequency,
    config.autoSyncEnabled ? 1 : 0, config.syncStatus, config.lastSyncError
  );
}

// ─── App Settings ─────────────────────────────────────────────────────────────
function getSetting(key) {
  const row = getDb().prepare('SELECT value FROM app_settings WHERE key=?').get(key);
  return row ? JSON.parse(row.value) : null;
}
function setSetting(key, value) {
  getDb().prepare('INSERT OR REPLACE INTO app_settings (key, value) VALUES (?,?)').run(key, JSON.stringify(value));
}

// ─── Audit Logs ───────────────────────────────────────────────────────────────
function addAuditLog(log) {
  getDb().prepare('INSERT INTO audit_logs (timestamp, userId, userName, action, entity, entityId, details) VALUES (?,?,?,?,?,?,?)').run(
    log.timestamp, log.userId, log.userName, log.action, log.entity, log.entityId, log.details
  );
  // Keep only last 1000
  getDb().prepare('DELETE FROM audit_logs WHERE id NOT IN (SELECT id FROM audit_logs ORDER BY id DESC LIMIT 1000)').run();
}
function getAuditLogs() {
  return getDb().prepare('SELECT * FROM audit_logs ORDER BY id DESC').all();
}

// ─── Export / Import ──────────────────────────────────────────────────────────
function exportAllData() {
  return {
    version: '2.0.0',
    exportDate: new Date().toISOString(),
    developer: 'MWA',
    schoolInfo: getSchoolInfo(),
    students: getStudents(),
    teachers: getTeachers(),
    feeRecords: getFeeRecords(),
    salaryRecords: getSalaryPayments(),
    classes: getClasses(),
    feeHeads: getFeeHeads(),
    academicYears: getAcademicYears(),
    users: getUsers().map(u => ({ ...u, passwordHash: '***HIDDEN***' })),
  };
}
function importAllData(data) {
  const db = getDb();
  const runImport = db.transaction(() => {
    if (data.schoolInfo) saveSchoolInfo(data.schoolInfo);
    if (data.classes) { db.prepare('DELETE FROM sections').run(); db.prepare('DELETE FROM classes').run(); data.classes.forEach(saveClass); }
    if (data.feeHeads) { db.prepare('DELETE FROM fee_heads').run(); data.feeHeads.forEach(saveFeeHead); }
    if (data.academicYears) { db.prepare('DELETE FROM academic_years').run(); data.academicYears.forEach(saveAcademicYear); }
    if (data.students) { db.prepare('DELETE FROM students').run(); data.students.forEach(s => { delete s.id; saveStudent(s); }); }
    if (data.feeRecords) { db.prepare('DELETE FROM fee_records').run(); data.feeRecords.forEach(r => { delete r.id; saveFeeRecord(r); }); }
    if (data.teachers) { db.prepare('DELETE FROM teachers').run(); data.teachers.forEach(t => { delete t.id; saveTeacher(t); }); }
    if (data.salaryRecords) { db.prepare('DELETE FROM salary_payments').run(); data.salaryRecords.forEach(saveSalaryPayment); }
  });
  runImport();
}

module.exports = {
  getSchoolInfo, saveSchoolInfo,
  getUsers, getUserByUsername, saveUser, deleteUser, getCurrentUser, setCurrentUser,
  getAcademicYears, saveAcademicYear,
  getClasses, saveClass, deleteClass,
  getFeeHeads, saveFeeHead,
  getStudents, saveStudent, deleteStudent,
  getFeeRecords, saveFeeRecord,
  getTeachers, saveTeacher, deleteTeacher,
  getSalaryPayments, saveSalaryPayment,
  getGoogleApiConfig, saveGoogleApiConfig,
  getSetting, setSetting,
  addAuditLog, getAuditLogs,
  exportAllData, importAllData,
};
