# School Fee Manager Pro — Desktop App

## Tech Stack
- **Frontend:** React + TypeScript + Tailwind CSS
- **Desktop:** Electron
- **Database:** SQLite (better-sqlite3) — Unlimited Storage

---

## Setup & Run

### Requirements
- Node.js 18 or higher
- npm

### Step 1 — Install Dependencies
```bash
npm install
```

### Step 2 — Run in Development Mode
```bash
npm run electron:dev
```
This will start Vite dev server + Electron together.

### Step 3 — Build Windows .exe Installer
```bash
npm run electron:build:win
```
Output will be in the `release/` folder as a `.exe` installer.

---

## Database Location
Data is saved in SQLite database at:
- **Windows:** `C:\Users\[Username]\AppData\Roaming\school-fee-manager-pro\school-fee-manager.db`
- **Mac:** `~/Library/Application Support/school-fee-manager-pro/school-fee-manager.db`

This means:
- ✅ Data is **never lost** on app update
- ✅ **Unlimited storage** (SQLite supports up to 281 TB)
- ✅ Works completely **offline**

---

## Features
- Student management
- Fee collection & receipts
- Teacher management & salary
- Google Sheets sync (backup)
- Local JSON backup/restore
- Reports (daily, monthly, class-wise)
- Multi-user with roles
- Audit logs

---

## Notes
- `electron/main.js` — Electron main process
- `electron/preload.js` — IPC bridge (secure communication)
- `electron/database.js` — SQLite operations
- `src/store/index.ts` — Frontend store (calls Electron IPC)
