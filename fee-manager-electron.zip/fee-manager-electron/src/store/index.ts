// Store for School Fee Manager Pro - Electron SQLite Backend
import type {
  SchoolInfo, User, AcademicYear, ClassInfo,
  FeeHead, Student, FeeRecord, GoogleApiConfig,
  Teacher, SalaryPayment
} from '../types';

// Helper to access Electron API
const api = () => (window as any).electronAPI;

// ─── School Info ─────────────────────────────────────────────────────────────
export const getSchoolInfo = (): SchoolInfo | null => {
  try { return api().getSchoolInfo(); } catch { return null; }
};
export const saveSchoolInfo = (info: SchoolInfo): void => {
  api().saveSchoolInfo(info);
  logAuditAction('UPDATE', 'SchoolInfo', 0, 'Updated school settings');
};

// ─── Users ───────────────────────────────────────────────────────────────────
export const getUsers = (): User[] => {
  try { return api().getUsers() || []; } catch { return []; }
};
export const getUserByUsername = (username: string): User | undefined => {
  try { return api().getUserByUsername(username) || undefined; } catch { return undefined; }
};
export const saveUser = (user: User): void => {
  const users = getUsers();
  const duplicate = users.find((u: User) => u.username.toLowerCase() === user.username.toLowerCase() && u.id !== user.id);
  if (duplicate) throw new Error(`Username "${user.username}" is already taken.`);
  api().saveUser(user);
};
export const deleteUser = (userId: number): void => {
  api().deleteUser(userId);
};
export const getCurrentUser = (): User | null => {
  try { return api().getCurrentUser() || null; } catch { return null; }
};
export const setCurrentUser = (user: User | null): void => {
  api().setCurrentUser(user);
};

// ─── Password Hashing ────────────────────────────────────────────────────────
const generateSalt = () => Math.random().toString(36).substring(2, 15);
export const hashPassword = (password: string, salt?: string): string => {
  const usedSalt = salt || generateSalt();
  let hash = password + usedSalt + '_MWA_SECURE_SALT';
  for (let i = 0; i < 3; i++) hash = btoa(hash).split('').reverse().join('');
  return `${usedSalt}:${hash}`;
};
export const verifyPassword = (password: string, storedHash: string): boolean => {
  if (!storedHash.includes(':')) {
    return btoa(password + '_hashed_salt_2026') === storedHash;
  }
  const [salt] = storedHash.split(':');
  return hashPassword(password, salt) === storedHash;
};
export const createAdminUser = (username: string, password: string, fullName: string, email: string): User => {
  const users = getUsers();
  const maxId = users.reduce((max: number, u: User) => Math.max(max, u.id), 0);
  const nextId = maxId + 1;
  const newUser: User = {
    id: nextId,
    userId: `USR-${String(nextId).padStart(3, '0')}`,
    username,
    passwordHash: hashPassword(password),
    fullName,
    email,
    role: 'admin',
    isActive: true,
    createdAt: new Date().toISOString(),
  };
  saveUser(newUser);
  return newUser;
};

// ─── Session ─────────────────────────────────────────────────────────────────
export const login = (username: string, password: string): User | null => {
  const user = getUserByUsername(username);
  if (user && user.isActive && verifyPassword(password, user.passwordHash)) {
    if (!user.passwordHash.includes(':')) {
      user.passwordHash = hashPassword(password);
      saveUser(user);
    }
    const updatedUser = { ...user, lastLogin: new Date().toISOString() };
    saveUser(updatedUser);
    setCurrentUser(updatedUser);
    logAuditAction('LOGIN', 'User', user.id, `User logged in: ${user.username}`);
    return updatedUser;
  }
  return null;
};
export const logout = (): void => {
  const user = getCurrentUser();
  if (user) logAuditAction('LOGOUT', 'User', user.id, `User logged out: ${user.username}`);
  setCurrentUser(null);
};

// ─── Academic Years ───────────────────────────────────────────────────────────
export const getAcademicYears = (): AcademicYear[] => {
  try { return api().getAcademicYears() || []; } catch { return []; }
};
export const saveAcademicYear = (year: AcademicYear): void => {
  api().saveAcademicYear(year);
};
export const getCurrentAcademicYear = (): AcademicYear | undefined => {
  return getAcademicYears().find((y: AcademicYear) => y.isCurrent);
};

// ─── Classes ─────────────────────────────────────────────────────────────────
export const getClasses = (): ClassInfo[] => {
  try { return api().getClasses() || []; } catch { return []; }
};
export const saveClass = (classInfo: ClassInfo): void => {
  api().saveClass(classInfo);
};
export const deleteClass = (classId: number): void => {
  api().deleteClass(classId);
};
export const initializeDefaultClasses = (): void => {
  if (getClasses().length > 0) return;
  const defaultClasses: ClassInfo[] = Array.from({ length: 12 }, (_, i) => ({
    id: i + 1,
    className: `Class ${i + 1}`,
    classCode: `CLS-${String(i + 1).padStart(2, '0')}`,
    displayOrder: i + 1,
    isActive: true,
    sections: [{ id: i + 1, classId: i + 1, sectionName: 'A', capacity: 40, isActive: true }],
  }));
  defaultClasses.forEach(saveClass);
};

// ─── Fee Heads ────────────────────────────────────────────────────────────────
export const getFeeHeads = (): FeeHead[] => {
  try { return api().getFeeHeads() || []; } catch { return []; }
};
export const saveFeeHead = (head: FeeHead): void => {
  api().saveFeeHead(head);
};
export const initializeDefaultFeeHeads = (): void => {
  if (getFeeHeads().length > 0) return;
  const defaultHeads: FeeHead[] = [
    { id: 1, headName: 'Tuition Fee', headCode: 'TUT', description: 'Monthly tuition fee', isRecurring: true, frequency: 'monthly', isMandatory: true, displayOrder: 1, isActive: true },
    { id: 2, headName: 'Admission Fee', headCode: 'ADM', description: 'One-time admission fee', isRecurring: false, frequency: 'one-time', isMandatory: true, displayOrder: 2, isActive: true },
    { id: 3, headName: 'Exam Fee', headCode: 'EXM', description: 'Examination fee', isRecurring: true, frequency: 'quarterly', isMandatory: true, displayOrder: 3, isActive: true },
    { id: 4, headName: 'Lab Fee', headCode: 'LAB', description: 'Laboratory fee', isRecurring: true, frequency: 'monthly', isMandatory: false, displayOrder: 4, isActive: true },
    { id: 5, headName: 'Library Fee', headCode: 'LIB', description: 'Library fee', isRecurring: true, frequency: 'annually', isMandatory: true, displayOrder: 5, isActive: true },
    { id: 6, headName: 'Sports Fee', headCode: 'SPT', description: 'Sports fee', isRecurring: true, frequency: 'annually', isMandatory: true, displayOrder: 6, isActive: true },
    { id: 7, headName: 'Computer Fee', headCode: 'CMP', description: 'Computer lab fee', isRecurring: true, frequency: 'monthly', isMandatory: false, displayOrder: 7, isActive: true },
    { id: 8, headName: 'Transport Fee', headCode: 'TRN', description: 'School transport fee', isRecurring: true, frequency: 'monthly', isMandatory: false, displayOrder: 8, isActive: true },
  ];
  defaultHeads.forEach(saveFeeHead);
};

// ─── Students ─────────────────────────────────────────────────────────────────
export const getStudents = (): Student[] => {
  try { return api().getStudents() || []; } catch { return []; }
};
export const saveStudent = (student: Student): void => {
  api().saveStudent(student);
};
export const deleteStudent = (studentId: number): void => {
  const result = api().deleteStudent(studentId);
  if (result?.softDeleted) {
    alert(`Note: This student has ${result.feeCount} fee records. Student has been marked as "Left" instead of being permanently removed.`);
  }
};
export const getStudentById = (id: number): Student | undefined => {
  return getStudents().find((s: Student) => s.id === id);
};
const getMaxSequence = (items: any[], idField: string, pattern: RegExp) => {
  let max = 0;
  items.forEach(item => {
    const match = item[idField]?.match(pattern);
    if (match) { const seq = parseInt(match[1], 10); if (seq > max) max = seq; }
  });
  return max;
};
export const generateStudentId = (): string => {
  const year = new Date().getFullYear();
  const maxSeq = getMaxSequence(getStudents(), 'studentId', /STU-\d{4}-(\d{4})/);
  return `STU-${year}-${String(maxSeq + 1).padStart(4, '0')}`;
};

// ─── Fee Records ──────────────────────────────────────────────────────────────
export const getFeeRecords = (): FeeRecord[] => {
  try { return api().getFeeRecords() || []; } catch { return []; }
};
export const saveFeeRecord = (record: FeeRecord): void => {
  api().saveFeeRecord(record);
};
export const generateReceiptNumber = (): string => {
  const year = new Date().getFullYear();
  const maxSeq = getMaxSequence(getFeeRecords(), 'receiptNumber', /RCP-\d{4}-(\d{4})/);
  return `RCP-${year}-${String(maxSeq + 1).padStart(4, '0')}`;
};
export const getStudentFeeRecords = (studentId: number): FeeRecord[] => {
  return getFeeRecords().filter((r: FeeRecord) => r.studentId === studentId);
};

// ─── Teachers ─────────────────────────────────────────────────────────────────
export const getTeachers = (): Teacher[] => {
  try { return api().getTeachers() || []; } catch { return []; }
};
export const saveTeacher = (teacher: Teacher): void => {
  api().saveTeacher(teacher);
};
export const deleteTeacher = (teacherId: number): void => {
  api().deleteTeacher(teacherId);
};
export const getTeacherById = (id: number): Teacher | undefined => {
  return getTeachers().find((t: Teacher) => t.id === id);
};
export const generateTeacherId = (): string => {
  const year = new Date().getFullYear();
  const maxSeq = getMaxSequence(getTeachers(), 'teacherId', /TCH-\d{4}-(\d{4})/);
  return `TCH-${year}-${String(maxSeq + 1).padStart(4, '0')}`;
};

// ─── Salary Payments ──────────────────────────────────────────────────────────
export const getSalaryPayments = (): SalaryPayment[] => {
  try { return api().getSalaryPayments() || []; } catch { return []; }
};
export const saveSalaryPayment = (payment: SalaryPayment): void => {
  api().saveSalaryPayment(payment);
};
export const generatePaymentId = (): string => {
  const year = new Date().getFullYear();
  const maxSeq = getMaxSequence(getSalaryPayments(), 'paymentId', /SAL-\d{4}-(\d{4})/);
  return `SAL-${year}-${String(maxSeq + 1).padStart(4, '0')}`;
};
export const getTeacherSalaryPayments = (teacherId: number): SalaryPayment[] => {
  return getSalaryPayments().filter((p: SalaryPayment) => p.teacherId === teacherId);
};

// ─── Google API Config ────────────────────────────────────────────────────────
export const getGoogleApiConfig = (): GoogleApiConfig => {
  try { return api().getGoogleApiConfig() || { isEnabled: false, syncFrequency: 15, autoSyncEnabled: true }; }
  catch { return { isEnabled: false, syncFrequency: 15, autoSyncEnabled: true }; }
};
export const saveGoogleApiConfig = (config: GoogleApiConfig): void => {
  api().saveGoogleApiConfig(config);
};

// ─── Setup ───────────────────────────────────────────────────────────────────
export const isSetupComplete = (): boolean => {
  return getUsers().length > 0 && getSchoolInfo() !== null;
};
export const markSetupComplete = (): void => {
  api().setSetting('setup_complete', true);
};

// ─── Theme ───────────────────────────────────────────────────────────────────
export const getTheme = (): 'light' | 'dark' => {
  try { return api().getSetting('theme') || 'light'; } catch { return 'light'; }
};
export const setTheme = (theme: 'light' | 'dark'): void => {
  api().setSetting('theme', theme);
  document.documentElement.classList.toggle('dark', theme === 'dark');
};

// ─── Currency ────────────────────────────────────────────────────────────────
export const formatCurrency = (amount: number): string => {
  return `PKR ${amount.toLocaleString('en-PK')}`;
};

// ─── Audit Logs ───────────────────────────────────────────────────────────────
export interface AuditLog {
  id: number;
  timestamp: string;
  userId: number;
  userName: string;
  action: 'CREATE' | 'UPDATE' | 'DELETE' | 'LOGIN' | 'LOGOUT' | 'IMPORT' | 'DELETE_SOFT' | 'DELETE_HARD' | 'PROMOTION';
  entity: string;
  entityId: number;
  details: string;
}
export const getAuditLogs = (): AuditLog[] => {
  try { return api().getAuditLogs() || []; } catch { return []; }
};
export const logAuditAction = (
  action: AuditLog['action'],
  entity: string,
  entityId: number,
  details: string
): void => {
  try {
    const currentUser = getCurrentUser();
    api().addAuditLog({
      timestamp: new Date().toISOString(),
      userId: currentUser?.id || 0,
      userName: currentUser?.fullName || 'System',
      action, entity, entityId, details,
    });
  } catch { /* ignore */ }
};

// ─── Backup & Export ─────────────────────────────────────────────────────────
export const exportAllData = (): string => {
  const data = api().exportAllData();
  return JSON.stringify(data, null, 2);
};
export const importAllData = (jsonData: string): { success: boolean; message: string } => {
  try {
    const data = JSON.parse(jsonData);
    if (!data.version || !data.exportDate) {
      return { success: false, message: 'Invalid backup file format' };
    }
    api().importAllData(data);
    logAuditAction('IMPORT', 'System', 0, 'Full database restore from backup');
    return { success: true, message: 'Data imported successfully!' };
  } catch {
    return { success: false, message: 'Failed to import data. Invalid file format.' };
  }
};

// ─── Storage Info ─────────────────────────────────────────────────────────────
export const getStorageInfo = () => ({
  usedMB: 'N/A',
  totalMB: 'Unlimited',
  percentage: '0',
  isCritical: false,
});

// ─── Student Promotion ────────────────────────────────────────────────────────
export const promoteStudents = (promotionData: { studentId: number; action: 'promote' | 'same' | 'passed_out' }[]) => {
  const students = getStudents();
  let promotedCount = 0, detainedCount = 0, passedOutCount = 0;
  for (const promotion of promotionData) {
    const student = students.find((s: Student) => s.id === promotion.studentId);
    if (!student) continue;
    if (promotion.action === 'promote') {
      if (student.classId >= 12) { saveStudent({ ...student, status: 'passed_out' as any, updatedAt: new Date().toISOString() }); passedOutCount++; }
      else { saveStudent({ ...student, classId: student.classId + 1, updatedAt: new Date().toISOString() }); promotedCount++; }
    } else if (promotion.action === 'passed_out') {
      saveStudent({ ...student, status: 'passed_out' as any, updatedAt: new Date().toISOString() }); passedOutCount++;
    } else { detainedCount++; }
  }
  logAuditAction('PROMOTION', 'Student', 0, `Processed: ${promotedCount} promoted, ${detainedCount} detained, ${passedOutCount} passed out`);
  return { total: promotionData.length, promoted: promotedCount, detained: detainedCount, passedOut: passedOutCount };
};

// ─── Misc ────────────────────────────────────────────────────────────────────
export const initializeDemoData = (): void => {};
export const getAllDataForSync = () => ({
  schoolInfo: getSchoolInfo(), students: getStudents(), teachers: getTeachers(),
  feeRecords: getFeeRecords(), salaryRecords: getSalaryPayments(),
  classes: getClasses(), feeHeads: getFeeHeads(), academicYears: getAcademicYears(),
});
export const getBackupFiles = () => [];
export const saveBackupFile = (_: any) => {};
export const deleteBackupFile = (_: string) => {};
export const getSalaryRecords = getSalaryPayments;
